import { computed, Injectable, signal } from '@angular/core';
import { Apartado } from '../interfaces/budget';

@Injectable({
  providedIn: 'root'
})
export class StateService {

  servicio    = signal<Apartado[]>([]);
  subTitulo   = signal<string[]>([]);
  
  servicioRO  = this.servicio.asReadonly();
  subTituloRO = this.subTitulo.asReadonly();

  constructor() { }

  /* servicio */
  setServicio(servicioNew: Apartado[]) {
    this.servicio.set(servicioNew);
  }

  addServicio(servicioNew: Apartado) {
    this.servicio.update(servicios => [...servicios, servicioNew]);
  }

  removeServicio(index: number) {
    this.servicio.update(servicios => servicios.filter((_, i) => i !== index));
  }

  /* Subtitulo */
  setSubTitulo(sub_titulo: string[]) {
    this.subTitulo.set(sub_titulo);
  }

  addSubTitulo(sub_titulo: string) {
    this.subTitulo.update(titulos => [...titulos, sub_titulo]);
  }

  removeSubTitulo(index: number) {
    this.subTitulo.update(titulos => titulos.filter((_, i) => i !== index));
  }


}
