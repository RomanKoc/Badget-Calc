import { ChangeDetectionStrategy, ChangeDetectorRef, Component } from '@angular/core';
import { Apartado, Budget, Extra, Seccion } from '../../interfaces/budget';
import { FormsModule } from '@angular/forms';
import { ButtonComponent } from '../../shared/button/button.component';
import { CdkDragDrop, CdkDragStart, DragDropModule, moveItemInArray } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { MonedasPipe } from '../../pipes/monedas.pipe';
import { MonedaPipe } from '../../pipes/moneda.pipe';

@Component({
  standalone: true,
  selector: 'app-calculator',
  imports: [FormsModule,ButtonComponent,DragDropModule,CommonModule,MonedasPipe,MonedaPipe],
  templateUrl: './calculator.component.html',
  styleUrl: './calculator.component.scss',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CalculatorComponent {
  apartados:(Seccion | Apartado)[] = [];
  
  new_serv:Apartado   = { id: 0, descripcion: 'Nuevo servicio', precio: 0, cantidad: 0 };
  new_sect:Seccion    = { id: 0, descripcion: 'Nueva seccion' };
  
  nombre:string       = 'Nombre presupuesto';
  monedas:string[]    = ['EUR', 'USD'];
  moneda_selet:string = this.monedas[0];
  descuento:Extra     = { aplicado: false, valor:10};
  descuentoApp:number = 0;
  iva:Extra           = { aplicado: false, valor:21};
  ivaApp:number       = 0;
  sub_total:number    = 0;

  constructor(private cdr: ChangeDetectorRef) {}
  
  ngOnInit(){
    this.obternerDeStorage();
  }

  ngDoCheck() {
    this.guardarEnStorage();
  }

  agregarSeccion():void {
    this.apartados.push(this.new_sect );
    this.new_sect = { id: this.apartados.length, descripcion: 'Nueva seccion' };
    this.new_serv = { id: this.apartados.length, descripcion: 'Nuevo servicio', precio: 0, cantidad: 0 };
  }
  agregarServicio():void {
    this.apartados.push({ ...this.new_serv });
    this.new_sect = { id: this.apartados.length, descripcion: 'Nueva seccion' };
    this.new_serv = { id: this.apartados.length, descripcion: 'Nuevo servicio', precio: 0, cantidad: 0 };
  }

  borrar(id:number):void{
    this.apartados = this.apartados.filter((apartado, index) => index !== id);
    this.apartados.forEach((apartado, index) => apartado.id = index);
  }

  isApartado(apartado: Seccion | Apartado): apartado is Apartado {
    return 'precio' in apartado;
  }

  aplicarDescuento():void{
    this.descuento.aplicado = !this.descuento.aplicado;
  }

  aplicarIva():void{
    this.iva.aplicado = !this.iva.aplicado;
  }
  

  calcularTotal():number {
    let total = this.apartados.reduce((total, apartado) => {
      if ('precio' in apartado && 'cantidad' in apartado) {
        return total + apartado.precio * apartado.cantidad;
      }
      return total;
    }, 0);
    
    this.sub_total = total;
    
    if (this.descuento.aplicado) {
      this.descuentoApp = (total * this.descuento.valor) / 100;
      total -= (total * this.descuento.valor) / 100;
    }
    
    if (this.iva.aplicado) {
      this.ivaApp = (total * this.iva.valor) / 100;
      total += (total * this.iva.valor) / 100
    };
    
    return total;
  }


  drop(event: CdkDragDrop<(Seccion | Apartado)[]>):void {
    moveItemInArray(this.apartados, event.previousIndex, event.currentIndex);
    this.apartados.forEach((apartado, index) => apartado.id = index); // reasignar ids
    this.cdr.detectChanges(); // Forzar detección de cambios
  }

  onDragStarted(event: CdkDragStart):void {
    const previewElement = event.source.getRootElement().querySelector('.cdk-drag-preview');
    if (previewElement) {
      const originalElement = event.source.getRootElement();
  
      // Copia los estilos manualmente
      const computedStyles = window.getComputedStyle(originalElement);
      (previewElement as HTMLElement).style.cssText = computedStyles.cssText;
    }
  }

  guardarEnStorage():void{
    const datos:Budget = {
      nombre: this.nombre,
      monedas: this.monedas,
      apartados: this.apartados,
      descuento: this.descuento,
      iva: this.iva,
      sub_total: this.sub_total
    };

    localStorage.setItem('budget-data', JSON.stringify(datos));
  }

  obternerDeStorage():boolean{
    const datos = localStorage.getItem('budget-data');
    if(datos){
      const { nombre, monedas, apartados, descuento, iva, sub_total } = JSON.parse(datos);
      this.nombre     = nombre;
      this.monedas    = monedas;
      this.apartados  = apartados;
      this.descuento  = descuento;
      this.iva        = iva;
      this.sub_total  = sub_total;
      return true;
    }
    return false;
  }
}
